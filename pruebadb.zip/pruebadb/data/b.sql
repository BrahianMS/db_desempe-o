CREATE TABLE customers(
id VARCHAR(15) PRIMARY KEY NOT NULL,
name VARCHAR(45) NOT NULL,
address VARCHAR(255) NOT NULL,
phone_number VARCHAR(25),
email VARCHAR(155) UNIQUE
);

CREATE TABLE bills(
id VARCHAR(10) PRIMARY KEY NOT NULL,
period VARCHAR(10) NOT NULL,
amount_bill DECIMAL(9,2) NOT NULL,
amount_paid DECIMAL(9,2) NOT NULL
);

CREATE TABLE transactions(
id VARCHAR(10) PRIMARY KEY NOT NULL,
date_hour DATETIME NOT NULL,
amount DECIMAL(9,2) NOT NULL,
status ENUM('Pendiente', 'Fallida', 'Completada'),
type ENUM('Pago de Factura'),
platform ENUM('Nequi','Daviplata') NOT NULL,
id_customer VARCHAR(15),
id_bill VARCHAR(10),
FOREIGN KEY (id_customer) REFERENCES customers(id) ON DELETE SET NULL ON UPDATE CASCADE,
FOREIGN KEY (id_bill) REFERENCES bills(id) ON DELETE SET NULL ON UPDATE CASCADE
);