const APP_URL = "http://localhost:3000/";

const tbody = document.getElementById('tbody');

// GET
(async function index() {
  try {
    const res = await fetch(APP_URL+'customers');
    const data = await res.json();
    console.log(data);
    
    console.log('GET:', data[0]);
    data[0].forEach(user => { // list each customer
        tbody.innerHTML += `<tr>
                                <td>${user.id}</td>
                                <td>${user.name}</td>
                                <td>${user.address}</td>
                                <td>${user.phone_number}</td>
                                <td>${user.email}</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-warning edit" data-id="${user.id}">Editar</button>
                                    <button type="button" class="btn btn-sm btn-danger del" data-id="${user.id}">Eliminar</button>
                                </td>
                            </tr>`
    });
  } catch (error) {
    console.error('Error en GET:', error);
  }
})()

//POST
async function store() {

  // Get all the form data
  const ident = document.getElementById('user_id').value.trim();
  const name = document.getElementById('name').value.trim();
  const address = document.getElementById('address').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const email = document.getElementById('email').value.trim();

  // Validates if any data is missing
  if (!ident || !name || !address || !phone || !email) {
    alert('Todos los campos son obligatorios.');
    return;
  }

  // Validates email format
  const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!emailPattern.test(email)) {
    alert('El email no es válido.');
    return;
  }
  if (isNaN(ident)) {
    alert('El ID debe ser un número válido');
    return;
  }
  try {
    const res = await fetch(APP_URL + 'customers', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: ident,
        name: name,
        address: address,
        phone_number: phone,
        email: email,
      }),
    });

    const data = await res.json();

    if (res.ok) {
      // Success message
      alert('Usuario creado exitosamente!');
      // Limpiar el formulario
      document.getElementById('addUserForm').reset();
    } else {
      // Error message
      alert(data.error || 'Error al crear el cliente.');
    }
  } catch (error) {
    console.error('Error en POST:', error);
    alert('Error de red. Intenta nuevamente.');
  }
}

//PUT
async function update(userId) {
  // Get all the form data update
  const ident2 = document.getElementById('user_id2').value.trim();
  const name2 = document.getElementById('name2').value.trim();
  const address2 = document.getElementById('address2').value.trim();
  const phone2 = document.getElementById('phone2').value.trim();
  const email2 = document.getElementById('email2').value.trim();

  // Validates if any data is missing
  if (!ident2 || !name2 || !address2 || !phone2 || !email2) {
    alert('Todos los campos son obligatorios.');
    return;
  }

  // Validates email format
  const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!emailPattern.test(email2)) {
    alert('El email no es válido.');
    return;
  }
  // Validate if id is a number
  if (isNaN(ident2)) {
    alert('El ID debe ser un número válido');
    return;
  }

  try {
    const res = await fetch(APP_URL + 'customers/' + userId, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: ident2,
        name: name2,
        address: address2,
        phone_number: phone2,
        email: email2,
      }),
    });

    const data = await res.json();

    if (res.ok) {
      // Success message
      alert('Usuario actualizado exitosamente!');

      document.getElementById('editUserForm').reset();
      upd.close();
    } else {
      // Error message
      alert(data.error || 'Error al actualizar el usuario.');
    }
  } catch (error) {
    console.error('Error en PUT:', error);
    alert('Error de red. Intenta nuevamente.');
  }
}


//DELETE
async function destroy(userId) {
  // Check the delete
  if (!confirm("¿Estás seguro de que deseas eliminar este usuario?")) {
    return;
  }

  try {
    const res = await fetch(APP_URL + 'customers/' + userId, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (res.ok) {
      // Success delete message
      console.log('DELETE: Usuario eliminado');

      alert('Usuario eliminado exitosamente');
    } else {
      // Error message
      const data = await res.json();
      console.error('Error en DELETE:', data.error || 'Error desconocido');
      alert('No se pudo eliminar el usuario. Intenta nuevamente.');
    }
  } catch (error) {
    console.error('Error en DELETE:', error);
    alert('Error de red. Intenta nuevamente.');
  }
}

//modals
const add = document.getElementById('modAddUser')
const upd = document.getElementById('modUpdUser')

document.getElementById('addUser').addEventListener('click', () => {
  add.showModal();
});
document.getElementById('close1').addEventListener('click', () => {add.close()})

document.getElementById('close2').addEventListener('click', () => {upd.close(); document.getElementById('editUserForm').reset()})

// add crud events
tbody.addEventListener('click', (e) => {
  if (e.target && e.target.classList.contains('edit')) {
      const id = e.target.dataset.id;
      upd.showModal();
        editUser(id)
  }
  if (e.target && e.target.classList.contains('del')) {
      const id = e.target.dataset.id;
      destroy(id);
  }
});

document.getElementById('addUserForm').addEventListener('submit', (e) => {
  e.preventDefault();
  store();
})

async function editUser(userId) {
    try {
        let res = await fetch(`${APP_URL}customers/${userId}`);
        let cust = await res.json();
        cust = cust[0]
        
          document.getElementById('user_id2').value = cust.id;
          document.getElementById('name2').value = cust.name;
          document.getElementById('address2').value = cust.address;
          document.getElementById('phone2').value = cust.phone_number;
          document.getElementById('email2').value = cust.email;
        setTimeout(() => {
        document.getElementById('editUserForm').addEventListener('submit', (e) => {
          e.preventDefault();
          update(userId)
        });
        
        },);
    } catch (error) {
        console.log('Error fetching event data for editing:', error);
    }
}
