# Postman collection

## Crud Endpoints

**Get**
'/customers'

```
[
    {
        "id": "111111111",
        "name": "John Montoya",
        "address": "Avenida Siempreviva",
        "phone_number": "12345678",
        "email": "jb@admin.com"
    },
    {
        "id": "112231541",
        "name": "Jennifer Phelps",
        "address": "392 Smith Corners Apt. 737East Angeltown, MO 64086",
        "phone_number": "248.695.2117",
        "email": "echristian@hotmail.com"
    }
]
```
**Get customer**
'/customers/:id'

example: '/customers/11426912'

```
[
    {
        "id": "11426912",
        "name": "Chad Garcia",
        "address": "195 Rollins Land Suite 478\nNorth Angelastad, IN 84674",
        "phone_number": "(530)211-7419",
        "email": "john27@schaefer.com"
    }
]
```

**Post**
'/customers'

**Put**
'/customers/:id'

**Delete**
'/customers/:id'

## Advanced Queries Endpoints

**Total payment by each customer**
'/total-pagado'

```
[
    {
        "customer_id": "149186547",
        "customer_name": "Angel Daniel",
        "total_paid": "38940.00"
    },
    {
        "customer_id": "475925688",
        "customer_name": "Matthew Wilson",
        "total_paid": "75145.00"
    }
]
```

**Information of pending bills**
'/facturas-pendientes'

```
[
    {
        "bill_id": "FAC1208",
        "amount_bill": "97457.00",
        "amount_paid": "96457.00",
        "pending_amount": "1000.00",
        "customer_id": "857630459",
        "customer_name": "Valerie Brown",
        "transaction_id": "TXN040",
        "date_hour": "2024-06-28T09:00:00.000Z",
        "transaction_amount": "96457.00"
    },
    {
        "bill_id": "FAC1328",
        "amount_bill": "159093.00",
        "amount_paid": "0.00",
        "pending_amount": "159093.00",
        "customer_id": "92651576",
        "customer_name": "Katherine Dunn",
        "transaction_id": "TXN011",
        "date_hour": "2024-06-01T11:00:00.000Z",
        "transaction_amount": "159093.00"
    }
]
```

**Nequi platform's transactions**
'/transacciones-nequi'

```
[
    {
        "transaction_id": "TXN001",
        "platform": "Nequi",
        "amount": "38940.00",
        "date_hour": "2024-06-01T15:00:00.000Z",
        "customer_id": "149186547",
        "customer_name": "Angel Daniel",
        "bill_id": "FAC7068"
    },
    {
        "transaction_id": "TXN006",
        "platform": "Nequi",
        "amount": "32428.00",
        "date_hour": "2024-07-17T02:00:00.000Z",
        "customer_id": "243553915",
        "customer_name": "Eric Klein",
        "bill_id": "FAC2190"
    }
]
```

**Daviplata platform's transactions**
'/transacciones-daviplata'