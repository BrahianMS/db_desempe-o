const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors')

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: '168.119.183.3',      
  user: 'root',   
  password: 'g0tIFJEQsKHm5$34Pxu1', 
  database: 'pd_john_montoya_vanrossum',
  port: '3307'
});

// Exponer el servidor en un puerto difinido.

app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});

//GET
app.get('/customers', async (req, res) => {
  try {
    let result = await pool.query(`SELECT id, name, address, phone_number, email
      FROM customers;`
    );
    if (result.length === 0) {
      return res.status(404).json({ error: 'No se encontraron clientes' });
    }
    return res.json(result);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});

//GET 1
app.get('/customers/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(id)) {
    return res.status(400).json({ error: 'El ID debe ser un número válido' });
  }
  try {
    let result = await pool.query(`SELECT id, name, address, phone_number, email
      FROM customers
      WHERE id = ?;`, [id]
    );
    if (result.length === 0) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }
    return res.json(result[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});


// POST
app.post('/customers', async (req, res) => {
  const { id, name, address, phone_number, email } = req.body;
  if (!id || !name || !address || !phone_number || !email) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }
  try {
    const result = await pool.query(
      'INSERT INTO customers (id, name, address, phone_number, email) VALUES (?, ?, ?, ?, ?)',
      [id, name, address, phone_number, email]
    );
    res.status(201).json({ message: 'Cliente creado exitosamente', userId: result.insertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al crear el cliente' + message});
  }
});


// PUT
app.put('/customers/:id', async (req, res) => {
  const { id } = req.params;
  const { name, address, phone_number, email } = req.body;
  if (!name || !address || !phone_number || !email) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }
  if (isNaN(id)) {
    return res.status(400).json({ error: 'El ID debe ser un número válido' });
  }
  try {
    const result = await pool.query(
      `UPDATE customers 
       SET name = ?, address = ?, phone_number = ?, email = ?
       WHERE id = ?`,
      [name, address, phone_number, email, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }
    res.json({ message: 'Cliente actualizado exitosamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el cliente' });
  }
});



// DELETE
app.delete('/customers/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(id)) {
    return res.status(400).json({ error: 'El ID debe ser un número válido' });
  }
  try {
    const result = await pool.query('DELETE FROM customers WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }
    res.json({ message: 'Cliente eliminado exitosamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al eliminar el cliente' });
  }
});

// Advanced Queries

// Total payment by each customer
app.get('/total-pagado', async (req, res) => {
  try {
    let result = await pool.query(`SELECT  c.id AS customer_id, c.name AS customer_name, SUM(t.amount) AS total_paid
          FROM customers c 
          JOIN transactions t ON c.id = t.id_customer
          GROUP BY c.id, c.name;`
    );
    if (result.length === 0) {
      return res.status(404).json({ error: 'Clientes no encontrados' });
    }
    return res.json(result[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});

// Information of pending bills
app.get('/facturas-pendientes', async (req, res) => {
  try {
    let result = await pool.query(`SELECT b.id AS bill_id, b.amount_bill, b.amount_paid, (b.amount_bill - b.amount_paid) AS pending_amount,
                  c.id AS customer_id, c.name AS customer_name, t.id AS transaction_id, t.date_hour, t.amount AS transaction_amount 
                  FROM bills b 
                  LEFT JOIN transactions t ON b.id = t.id_bill 
                  JOIN customers c ON t.id_customer = c.id
                  WHERE b.amount_paid < b.amount_bill;`);
    if (result.length === 0) {
      return res.status(404).json({ error: 'Datos no encontrados' });
    }
    return res.json(result[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});

// Nequi platform's transactions
app.get('/transacciones-nequi', async (req, res) => {
  try {
    let result = await pool.query(`SELECT t.id AS transaction_id, t.platform, t.amount, t.date_hour, c.id AS customer_id,
                c.name AS customer_name, b.id AS bill_id
                FROM transactions t 
                JOIN customers c ON t.id_customer = c.id 
                JOIN bills b ON t.id_bill = b.id 
                WHERE t.platform = 'Nequi';`);
    if (result.length === 0) {
      return res.status(404).json({ error: 'Datos no encontrados' });
    }
    return res.json(result[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});

// Daviplata platform's transactions
app.get('/transacciones-daviplata', async (req, res) => {
  try {
    let result = await pool.query(`SELECT t.id AS transaction_id, t.platform, t.amount, t.date_hour, c.id AS customer_id,
                c.name AS customer_name, b.id AS bill_id
                FROM transactions t 
                JOIN customers c ON t.id_customer = c.id 
                JOIN bills b ON t.id_bill = b.id 
                WHERE t.platform = 'Daviplata';`);
    if (result.length === 0) {
      return res.status(404).json({ error: 'Datos no encontrados' });
    }
    return res.json(result[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Error al obtener los datos' });
  }
});